package UI;


public class Applicant_UI 
{
    public static void display()
    {
        System.out.println("___________________________________________________________________________________________");
        System.out.println("Welcome to the Applicant UI!");
        
    }

}
