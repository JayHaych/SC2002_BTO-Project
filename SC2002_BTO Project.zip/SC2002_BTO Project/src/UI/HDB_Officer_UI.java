package UI;

public class HDB_Officer_UI 
{
    public static void display()
    {
        System.out.println("___________________________________________________________________________________________");
        System.out.println("Welcome to the HDB Officer UI!");
    }

}
