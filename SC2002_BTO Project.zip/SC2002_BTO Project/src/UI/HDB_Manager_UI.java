package UI;

public class HDB_Manager_UI 
{
    public static void display()
    {
        System.out.println("___________________________________________________________________________________________");
        System.out.println("Welcome to the HDB Manager UI!");
    }
}
